using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class LightMask : MonoBehaviour
{
    public Transform character; // Drag karakter ke sini melalui Inspector
    public Vector3 offset; // Offset jika diperlukan (defaultnya 0,0,0)

    void Update()
    {
        if (character != null)
        {
            // Atur posisi Light Mask sesuai posisi karakter + offset
            transform.position = character.position + offset;
        }
    }
}
