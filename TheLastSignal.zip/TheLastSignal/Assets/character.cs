using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class CharacterMovement : MonoBehaviour
{
    public float moveSpeed = 5f; // Kecepatan gerak karakter
    private bool isFacingRight = true; // Untuk mengecek arah karakter

    private Rigidbody2D rb;
    public Transform mainCamera; // Kamera utama yang mengikuti karakter
    private Animator animator; // Referensi ke Animator

    private Vector2 movementInput; // Menyimpan input gerakan

    [Header("Camera Settings")]
    public float cameraFollowSpeed = 2f; // Kecepatan kamera mengikuti karakter

    private bool isDead = false; // Untuk mengecek apakah karakter mati

    void Start()
    {
        rb = GetComponent<Rigidbody2D>();
        animator = GetComponent<Animator>(); // Ambil komponen Animator

        // Kunci rotasi pada sumbu Z untuk mencegah perputaran
        rb.constraints = RigidbodyConstraints2D.FreezeRotation;

        // Jika mainCamera belum di-assign, cari kamera utama
        if (mainCamera == null)
        {
            if (Camera.main != null)
            {
                mainCamera = Camera.main.transform;
            }
            else
            {
                Debug.LogError("No Main Camera found in the scene! Please assign a camera.");
            }
        }
    }

    void Update()
    {
        if (!isDead) // Jangan ambil input jika karakter mati
        {
            GetInput(); // Ambil input dari player
            UpdateCameraPosition(); // Perbarui posisi kamera
        }
    }

    void FixedUpdate()
    {
        if (!isDead) // Jangan bergerak jika karakter mati
        {
            Move(); // Gerakan dilakukan di FixedUpdate untuk akurasi fisika
        }
    }

    void GetInput()
    {
        // Ambil input horizontal dan vertikal
        float moveHorizontal = Input.GetAxisRaw("Horizontal");
        float moveVertical = Input.GetAxisRaw("Vertical");

        // Simpan input ke vector
        movementInput = new Vector2(moveHorizontal, moveVertical).normalized;

        // Update parameter Animator
        bool isRunning = movementInput.magnitude > 0; // Jika ada input, isRunning = true
        animator.SetBool("isrunning", isRunning);

        // Flip karakter jika bergerak ke arah lain
        if (moveHorizontal > 0 && !isFacingRight)
        {
            Flip();
        }
        else if (moveHorizontal < 0 && isFacingRight)
        {
            Flip();
        }
    }

    void Move()
    {
        // Update posisi karakter berdasarkan input
        rb.velocity = movementInput * moveSpeed;
    }

    void Flip()
    {
        isFacingRight = !isFacingRight;

        // Membalikkan skala karakter di sumbu X untuk mengubah arah
        Vector3 scaler = transform.localScale;
        scaler.x *= -1;
        transform.localScale = scaler;
    }

    void UpdateCameraPosition()
    {
        if (mainCamera != null)
        {
            // Posisi target kamera (mengikuti posisi karakter)
            Vector3 targetPosition = new Vector3(transform.position.x, transform.position.y, mainCamera.position.z);

            // Lerp untuk transisi halus
            mainCamera.position = Vector3.Lerp(mainCamera.position, targetPosition, cameraFollowSpeed * Time.deltaTime);
        }
        else
        {
            Debug.LogWarning("Main Camera is not assigned!");
        }
    }

    // Fungsi untuk mematikan karakter
    public void Die()
    {
        if (isDead) return; // Jangan lakukan apa-apa jika sudah mati

        isDead = true; // Tandai bahwa karakter sudah mati
        animator.SetTrigger("isdeath"); // Aktifkan animasi kematian

        // Nonaktifkan gerakan karakter
        rb.velocity = Vector2.zero;
        this.enabled = false;

        // Opsional: Tambahkan delay sebelum restart atau game over
        StartCoroutine(HandleDeath());
    }

    private IEnumerator HandleDeath()
    {
        yield return new WaitForSeconds(2f); // Tunggu animasi selesai
        // Restart scene atau ke layar game over
        UnityEngine.SceneManagement.SceneManager.LoadScene(UnityEngine.SceneManagement.SceneManager.GetActiveScene().name);
    }

    private void OnCollisionEnter2D(Collision2D collision)
    {
        if (collision.gameObject.CompareTag("Enemy")) // Jika bersentuhan dengan Enemy
        {
            Die();
        }
    }
}
