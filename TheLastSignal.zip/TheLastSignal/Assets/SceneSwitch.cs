using UnityEngine;
using UnityEngine.SceneManagement;

public class SceneSwitch : MonoBehaviour
{
    private bool isPlayerNear = false; // Mengecek apakah pemain mendekati collider
    private bool isTaskActive = false; // Mengecek apakah task sedang aktif
    private float taskTimer = 50f; // Durasi task
    private bool isTaskComplete = false; // Status task selesai
    private Vector3 playerLastPosition; // Posisi terakhir pemain

    public Transform playerTransform; // Tambahkan referensi ke transform karakter

    private void Update()
    {
        // Cek jika pemain menekan E saat berada di dekat collider
        if (isPlayerNear && Input.GetKeyDown(KeyCode.E) && !isTaskActive)
        {
            StartTask();
        }

        // Jika task aktif, hitung waktu mundur
        if (isTaskActive)
        {
            taskTimer -= Time.deltaTime;

            if (taskTimer <= 0 && !isTaskComplete)
            {
                EndTask(false); // Task gagal
            }
        }
    }

    private void OnTriggerEnter2D(Collider2D other)
    {
        if (other.CompareTag("Player"))
        {
            isPlayerNear = true; // Pemain mendekati collider
        }
    }

    private void OnTriggerExit2D(Collider2D other)
    {
        if (other.CompareTag("Player"))
        {
            isPlayerNear = false; // Pemain menjauh dari collider
        }
    }

    private void StartTask()
    {
        isTaskActive = true;
        playerLastPosition = playerTransform.position; // Simpan posisi terakhir karakter
        SceneManager.LoadScene(1, LoadSceneMode.Additive); // Buka scene task secara additive
    }

    public void CompleteTask()
    {
        isTaskComplete = true;
        EndTask(true); // Task berhasil
    }

private void EndTask(bool success)
{
    if (success)
    {
        Debug.Log("Task selesai! Kembali ke scene utama.");
    }
    else
    {
        Debug.Log("Task gagal! Kembali ke scene utama.");
    }

    // Tutup scene task (jangan reload scene utama)
    SceneManager.UnloadSceneAsync(1); // Tutup scene task
    playerTransform.position = playerLastPosition; // Kembalikan posisi karakter

    ResetTask(); // Reset status task
}

    private void ResetTask()
    {
        isTaskActive = false;
        taskTimer = 100f;
        isTaskComplete = false;
    }
}