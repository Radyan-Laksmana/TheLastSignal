﻿using UnityEngine;

public interface ILineWireRenderer
{
   LineRenderer Wire { get; }
}
