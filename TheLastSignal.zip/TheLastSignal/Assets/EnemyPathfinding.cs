using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class EnemyPathfinding : MonoBehaviour
{
    [SerializeField] private float moveSpeed = 2f; // Kecepatan gerak musuh
    private Rigidbody2D rb;
    private Vector2 moveDir;

    private void Awake() {
        rb = GetComponent<Rigidbody2D>();
    }

    private void FixedUpdate() {
        if (rb != null) {
            rb.velocity = moveDir * moveSpeed; // Gunakan velocity untuk pergerakan
        }
    }

    /// <summary>
    /// Mengatur arah tujuan gerakan musuh.
    /// </summary>
    /// <param name="targetDirection">Arah yang dituju.</param>
    public void MoveTo(Vector2 targetDirection) {
        moveDir = targetDirection.normalized; // Normalisasi arah untuk memastikan kecepatan konsisten
    }

    /// <summary>
    /// Menghentikan semua pergerakan musuh.
    /// </summary>
    public void StopMovement() {
        moveDir = Vector2.zero; // Menghentikan gerakan dengan mengosongkan vektor arah
    }
}
