using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class EnemyAI : MonoBehaviour
{
    private enum State {
        Roaming,
        Chasing
    }

    private State state;
    private EnemyPathfinding enemyPathfinding;
    private Transform target;
    [SerializeField] private float chaseRange = 5f;

    public static bool isTaskOpen = false; // Status global untuk memeriksa apakah task UI aktif

    private void Awake() {
        enemyPathfinding = GetComponent<EnemyPathfinding>();
        state = State.Roaming;
    }

    private void Start() {
        target = GameObject.FindWithTag("Player").transform;
        StartCoroutine(EnemyBehaviorRoutine());
    }

    // Mengubah aksesibilitas metode menjadi protected agar dapat diakses lebih luas jika dibutuhkan
    protected internal IEnumerator EnemyBehaviorRoutine() {
        while (true) {
            if (isTaskOpen) {
                // Jika UI task aktif, hentikan semua gerakan Enemy
                enemyPathfinding.StopMovement();
            }
            else {
                switch (state) {
                    case State.Roaming:
                        Vector2 roamPosition = GetRoamingPosition();
                        enemyPathfinding.MoveTo(roamPosition);
                        if (Vector2.Distance(transform.position, target.position) < chaseRange) {
                            state = State.Chasing;
                        }
                        break;
                    case State.Chasing:
                        enemyPathfinding.MoveTo((target.position - transform.position).normalized);
                        if (Vector2.Distance(transform.position, target.position) > chaseRange) {
                            state = State.Roaming;
                        }
                        break;
                }
            }

            yield return new WaitForSeconds(0.2f);
        }
    }

    private Vector2 GetRoamingPosition() {
        return new Vector2(Random.Range(-1f, 1f), Random.Range(-1f, 1f)).normalized;
    }

    private void OnDrawGizmosSelected() {
        Gizmos.color = Color.red;
        Gizmos.DrawWireSphere(transform.position, chaseRange);
    }
}
